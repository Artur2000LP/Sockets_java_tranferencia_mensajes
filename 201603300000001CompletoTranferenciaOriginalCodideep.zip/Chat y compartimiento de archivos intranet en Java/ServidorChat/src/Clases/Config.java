/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author KAAF0
 */
public class Config {
    private int portListener;
    
    public Config()
    {
        portListener=7777;
    }

    /**
     * @return the portListener
     */
    public int getPortListener() {
        return portListener;
    }

    /**
     * @param portListener the portListener to set
     */
    public void setPortListener(int portListener) {
        this.portListener = portListener;
    }
}
