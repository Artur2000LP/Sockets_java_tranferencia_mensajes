/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author KAAF0
 */
public class Config {
    private int portServer;
    private String ipServer;
    private int portShare;
    
    public Config()
    {
        portServer=7777;
        ipServer="192.168.1.105";
        portShare=4444;
    }

    /**
     * @return the port
     */
    public int getPortServer() {
        return portServer;
    }

    /**
     * @param port the port to set
     */
    public void setPortServer(int port) {
        this.portServer = port;
    }

    /**
     * @return the ipServer
     */
    public String getIpServer() {
        return ipServer;
    }

    /**
     * @param ipServer the ipServer to set
     */
    public void setIpServer(String ipServer) {
        this.ipServer = ipServer;
    }

    /**
     * @return the portShare
     */
    public int getPortShare() {
        return portShare;
    }

    /**
     * @param portShare the portShare to set
     */
    public void setPortShare(int portShare) {
        this.portShare = portShare;
    }
}
