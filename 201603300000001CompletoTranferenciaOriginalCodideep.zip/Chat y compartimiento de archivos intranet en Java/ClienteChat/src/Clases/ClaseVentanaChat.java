/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Formularios.VentanaChat;

/**
 *
 * @author kaaf
 */
public class ClaseVentanaChat {
    private static VentanaChat V;
    public void setVentanaChat(VentanaChat V)
    {
        this.V=V;
    }
    public VentanaChat getVentanaChat()
    {
        return this.V;
    }
}
