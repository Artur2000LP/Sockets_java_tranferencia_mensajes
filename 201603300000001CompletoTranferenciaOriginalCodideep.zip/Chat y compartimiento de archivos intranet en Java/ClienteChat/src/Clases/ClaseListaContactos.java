/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.awt.Container;

/**
 *
 * @author kaaf
 */
public class ClaseListaContactos {
    private static Container Contenedor;
    public void setContenedor(Container Contenedor)
    {
        this.Contenedor=Contenedor;
    }
    public Container getContenedor()
    {
        return this.Contenedor;
    }
}
